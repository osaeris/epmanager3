=== Writr ===

== Changelog ==

= 1.0.8 - Feb 05 2014 = Minor fix to body tag positioning

= 1.0.7 - Dec 03 2013 =
* Add Featured Image to single post/page

= 1.0.6 - Nov 06 2013 =
* Fix Walker_Nav_Menu() php errors

= 1.0.5 - Nov 02 2013 =
* New responsive video JS to let users change the size of the videos and not be 100% automatically

= 1.0.4 - Nov 01 2013 =
* New theme option: Wider Content Area

= 1.0.3 - Nov 01 2013 =
* Cleaned template-tags.php

= 1.0.2 - Oct 31 2013 =
* Fixed issue of undefined writr_categorized_blog function in 404.php

= 1.0.1 - Oct 31 2013 =
* Display navigation only if user configured Primary Menu

= 1.0 - Oct 31 2013 =
* Initial release of Writr